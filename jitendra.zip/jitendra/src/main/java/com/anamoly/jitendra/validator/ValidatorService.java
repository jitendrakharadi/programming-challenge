package com.anamoly.jitendra.validator;

import com.anamoly.jitendra.model.AnamolyDetectorRS;

public interface ValidatorService {
	public String validateJsonRQ(String rq);
	public String validateJsonRQForAnamolyDetector(String rq);

}
