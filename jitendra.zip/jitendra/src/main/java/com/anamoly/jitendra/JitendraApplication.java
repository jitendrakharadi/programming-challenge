package com.anamoly.jitendra;

import java.math.BigDecimal;

import javax.annotation.PostConstruct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.anamoly.jitendra.model.AnamolyModel;
import com.anamoly.jitendra.util.AnamolyConstant;

@SpringBootApplication
@EnableAutoConfiguration
@EnableScheduling
@Configuration
@ComponentScan({"com.anamoly.jitendra.controller", "com.anamoly.jitendra.model", "com.airlinestech.intg.validator"})
public class JitendraApplication {

	public static void main(String[] args) {
		SpringApplication.run(JitendraApplication.class, args);
	}
	
	@PostConstruct
	private void init(){
		AnamolyModel anamolyDetectorRQ=new AnamolyModel("fd0a635d-2aaf-4460-a817-6353e1b6c050", "UpperBoundThresholdAnomalyDetector", new BigDecimal("27.0"));
		AnamolyConstant.thresholdAnamoly=anamolyDetectorRQ;
		System.out.println("data to be load at the time of startup");
	}

}
