package com.anamoly.jitendra.validator;

import java.math.BigDecimal;

import com.anamoly.jitendra.model.AnamolyDetectorRQ;
import com.anamoly.jitendra.model.AnamolyDetectorRS;
import com.anamoly.jitendra.model.AnamolyModel;
import com.anamoly.jitendra.util.AnamolyConstant;
import com.google.gson.Gson;

public class ValidatorServiceImpl implements ValidatorService {

	@Override
	public String validateJsonRQ(String rq) {
		// TODO Auto-generated method stub
		Gson gson = new Gson();
		AnamolyDetectorRQ anamolyDetectorRQ = new AnamolyDetectorRQ();
		AnamolyDetectorRS anamolyDetectorRS = null;
		String jsonRS = "{}";
		try {
			anamolyDetectorRQ = gson.fromJson(rq, AnamolyDetectorRQ.class);
		} catch (Exception e) {
			anamolyDetectorRQ = null;
		}
		if (null != anamolyDetectorRQ) {
			anamolyDetectorRS = new AnamolyDetectorRS(anamolyDetectorRQ.getEventId(), anamolyDetectorRQ.getSensorId(),
					anamolyDetectorRQ.getTimestamp(), anamolyDetectorRQ.getValue(), "NO_MODEL", "", "");
			jsonRS = gson.toJson(anamolyDetectorRS);
		}
		return jsonRS;
	}

	@Override
	public String validateJsonRQForAnamolyDetector(String rq) {
		// TODO Auto-generated method stub
		Gson gson = new Gson();
		AnamolyDetectorRQ anamolyDetectorRQ = new AnamolyDetectorRQ();
		AnamolyDetectorRS anamolyDetectorRS = null;
		String jsonRS = "{}";
		try {
			anamolyDetectorRQ = gson.fromJson(rq, AnamolyDetectorRQ.class);
		} catch (Exception e) {
			anamolyDetectorRQ = null;
		}
		if (null != anamolyDetectorRQ) {
			String eventId = anamolyDetectorRQ.getEventId();
			String sensorId = anamolyDetectorRQ.getSensorId();
			Integer timestamp = anamolyDetectorRQ.getTimestamp();
			BigDecimal value = anamolyDetectorRQ.getValue();
			String status = "NO_MODEL";
			String cause = "";
			String message = "";
			AnamolyModel anamolyModel = AnamolyConstant.thresholdAnamoly;
			if (anamolyModel.getThreshold().compareTo(anamolyDetectorRQ.getValue()) <= 0) {
				status = "ANOMALY";
				cause = "Upper Bound Threshold Detector";
				message = "Exceeds threshold";
			} else {
				status = "NO_ANOMALY";
			}
			anamolyDetectorRS = new AnamolyDetectorRS(eventId, sensorId, timestamp, value, status, cause, message);
			jsonRS = gson.toJson(anamolyDetectorRS);
		}
		return jsonRS;
	}

}
