package com.anamoly.jitendra.util;

import org.springframework.stereotype.Component;

import com.anamoly.jitendra.model.AnamolyModel;

@Component
public class AnamolyConstant {

	public static AnamolyModel thresholdAnamoly;

}
