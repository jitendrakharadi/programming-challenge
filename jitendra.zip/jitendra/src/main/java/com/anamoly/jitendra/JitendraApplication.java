package com.anamoly.jitendra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JitendraApplication {

	public static void main(String[] args) {
		SpringApplication.run(JitendraApplication.class, args);
	}

}
