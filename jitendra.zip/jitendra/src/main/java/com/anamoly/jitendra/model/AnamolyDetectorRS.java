package com.anamoly.jitendra.model;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class AnamolyDetectorRS {
	String eventId;
	String sensorId;
	Integer timestamp;
	BigDecimal value;
	String status;
	String cause;
	String message;

	public AnamolyDetectorRS(String eventId, String sensorId, Integer timestamp, BigDecimal value, String status,
			String cause, String message) {
		super();
		this.eventId = eventId;
		this.sensorId = sensorId;
		this.timestamp = timestamp;
		this.value = value;
		this.status = status;
		this.cause = cause;
		this.message = message;
	}

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

	public String getSensorId() {
		return sensorId;
	}

	public void setSensorId(String sensorId) {
		this.sensorId = sensorId;
	}

	public Integer getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Integer timestamp) {
		this.timestamp = timestamp;
	}

	public BigDecimal getValue() {
		return value;
	}

	public void setValue(BigDecimal value) {
		this.value = value;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCause() {
		return cause;
	}

	public void setCause(String cause) {
		this.cause = cause;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "AnamolyDetectorRS [eventId=" + eventId + ", sensorId=" + sensorId + ", timestamp=" + timestamp
				+ ", value=" + value + ", status=" + status + ", cause=" + cause + ", message=" + message + "]";
	}

}
