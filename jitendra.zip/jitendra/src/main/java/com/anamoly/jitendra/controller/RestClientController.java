package com.anamoly.jitendra.controller;

import javax.servlet.http.HttpServletRequest;
import org.springframework.http.HttpEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.anamoly.jitendra.validator.ValidatorService;
import com.anamoly.jitendra.validator.ValidatorServiceImpl;

@RestController
public class RestClientController {

	@RequestMapping(value = "/api/event", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public String callApiEvent(HttpEntity<String> httpEntity, HttpServletRequest request) throws Exception {
		String jsonRQ = httpEntity.getBody();
		ValidatorService validatorService = new ValidatorServiceImpl();
		return validatorService.validateJsonRQ(jsonRQ);
	}

	@RequestMapping(value = "/api/anamolyCheck", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public String callAnamolyApi(HttpEntity<String> httpEntity, HttpServletRequest request) throws Exception {
		String jsonRQ = httpEntity.getBody();
		ValidatorService validatorService = new ValidatorServiceImpl();
		return validatorService.validateJsonRQForAnamolyDetector(jsonRQ);
	}
}
