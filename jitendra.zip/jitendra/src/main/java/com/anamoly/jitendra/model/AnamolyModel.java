package com.anamoly.jitendra.model;

import java.math.BigDecimal;

public class AnamolyModel {
	String sensorId;
	String model;
	public AnamolyModel(String sensorId, String model, BigDecimal threshold) {
		super();
		this.sensorId = sensorId;
		this.model = model;
		this.threshold = threshold;
	}
	BigDecimal threshold;
	public String getSensorId() {
		return sensorId;
	}
	public void setSensorId(String sensorId) {
		this.sensorId = sensorId;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public BigDecimal getThreshold() {
		return threshold;
	}
	public void setThreshold(BigDecimal threshold) {
		this.threshold = threshold;
	}
}
