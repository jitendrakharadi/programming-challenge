package com.anamoly.jitendra.model;

import java.math.BigDecimal;

public class AnamolyDetectorRQ {
	String eventId;
	String sensorId;
	Integer timestamp;
	BigDecimal value;

	public AnamolyDetectorRQ() {

	}

	public AnamolyDetectorRQ(String eventId, String sensorId, Integer timestamp, BigDecimal value) {
		super();
		this.eventId = eventId;
		this.sensorId = sensorId;
		this.timestamp = timestamp;
		this.value = value;
	}

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

	public String getSensorId() {
		return sensorId;
	}

	public void setSensorId(String sensorId) {
		this.sensorId = sensorId;
	}

	public Integer getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Integer timestamp) {
		this.timestamp = timestamp;
	}

	public BigDecimal getValue() {
		return value;
	}

	public void setValue(BigDecimal value) {
		this.value = value;
	}
}
